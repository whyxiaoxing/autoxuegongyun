"""
RustMatch - 高性能模板匹配库（Rust 实现，零 Python 依赖）
=========================================================

核心特性：
- 使用归一化互相关（NCC）计算匹配置信度，抗亮度/对比度变化；
- 默认启用**自适应多尺度（DPI 无关）搜索**，同一模板可匹配不同尺寸/像素密度的截图；
- 积分图 + 图像金字塔 + 粗到细搜索，支持大图快速定位；
- 内置校验门槛：平坦模板、平坦色块（JPEG 抖动）不会产生误匹配；
- 多线程并行，零 Python 依赖（不需要 numpy / pillow / opencv）。

坐标约定：
    所有返回坐标均为**源图像素坐标**，(x, y) 是匹配区域的左上角。

缩放约定：
    - result.scale 是模板匹配倍率，1.0 表示模板原始尺寸；
    - result.matched_width / matched_height 是模板在源图中的实际像素尺寸；
    - 由于模板像素是整数，倍率可能存在约 1/模板宽度 的量化误差。

快速开始：
    >>> import rustmatch
    >>> r = rustmatch.find("screen.png", "icon.png")
    >>> if r:
    ...     print(r.x, r.y, r.scale, r.confidence)

函数列表：
    find: 单目标匹配（文件路径，推荐）
    find_all: 多目标匹配（文件路径）
    find_bytes: 单目标匹配（图像字节）
    find_all_bytes: 多目标匹配（图像字节）
    find_raw: 单目标匹配（原始灰度像素）
    find_all_raw: 多目标匹配（原始灰度像素）
    get_size: 读取图像尺寸
    get_size_bytes: 从字节读取图像尺寸
    set_threads: 设置线程数
    version: 获取库版本
"""

from __future__ import annotations

from typing import List, Optional, Sequence, Union

__version__ = "0.1.0"
__author__ = "Junjie Duan"
__all__ = [
    # 核心类
    "MatchResult",
    # 文件路径接口（推荐）
    "find",
    "find_all",
    # 图像字节接口
    "find_bytes",
    "find_all_bytes",
    # 原始像素接口
    "find_raw",
    "find_all_raw",
    # 工具函数
    "get_size",
    "get_size_bytes",
    "set_threads",
    "version",
]

# 从 Rust 扩展模块导入底层实现
from rustmatch._core import (
    MatchResult,
    find_template as _find_template,
    find_all_templates as _find_all_templates,
    find_template_bytes as _find_template_bytes,
    find_all_templates_bytes as _find_all_templates_bytes,
    find_template_raw as _find_template_raw,
    find_all_templates_raw as _find_all_templates_raw,
    get_image_size as _get_image_size,
    get_image_size_bytes as _get_image_size_bytes,
    set_num_threads,
    version as _version,
)

_ScaleArgs = Optional[Sequence[float]]


def _scale_kwargs(
    scales: _ScaleArgs,
    min_scale: Optional[float],
    max_scale: Optional[float],
    scale_step: float,
    min_std: float,
    max_candidates: int,
):
    """
    统一整理缩放相关参数，再传给 Rust 底层。

    参数：
        scales: 显式倍率列表；为 None 时使用自适应范围。
        min_scale: 自适应范围下界；None 表示自动。
        max_scale: 自适应范围上界；None 表示自动。
        scale_step: 线性步长；0 表示使用自动几何级数网格。
        min_std: 平坦区域门槛（灰度标准差）。
        max_candidates: 全分辨率细化的候选数量。

    返回：
        可直接作为关键字参数展开传给底层函数的字典。
    """
    return dict(
        scales=list(scales) if scales is not None else None,
        min_scale=min_scale,
        max_scale=max_scale,
        scale_step=float(scale_step),
        min_std=float(min_std),
        max_candidates=int(max_candidates),
    )


def find(
    source: str,
    template: str,
    threshold: float = 0.8,
    scales: _ScaleArgs = None,
    min_scale: Optional[float] = None,
    max_scale: Optional[float] = None,
    scale_step: float = 0.0,
    min_std: float = 2.0,
    max_candidates: int = 6,
) -> Optional[MatchResult]:
    """
    在源图中查找单个最佳匹配（文件路径接口，推荐）。

    默认会对模板做**自适应多尺度搜索**（约 0.25x–2.0x，受源图尺寸约束），
    因此不需要预先知道截图的 DPI/缩放倍率。源图只解码一次。

    参数：
        source:
            源图文件路径（支持 PNG、JPEG、BMP 等常见格式）。
        template:
            模板图文件路径。
        threshold:
            最终 NCC 置信度门槛，范围 0.0–1.0，默认 0.8。
            只有最终全分辨率分数 >= threshold 才会返回结果。
        scales:
            显式倍率列表，例如 [1.0, 1.25, 1.5]。
            传入后会按列表中的倍率精确搜索，不再自动生成范围。
        min_scale:
            自适应范围下界；None 表示自动（通常约 0.25，
            模板相对源图很大时会自动下调）。
        max_scale:
            自适应范围上界；None 表示自动（默认 2.0，
            且不会超过模板能放入源图的最大倍率）。
        scale_step:
            线性步长；0 表示使用自动几何级数网格（推荐，约 10% 步进）。
        min_std:
            平坦区域门槛，单位是灰度级标准差，默认 2.0。
            局部窗口标准差低于该值时直接判为 0 分，
            用于抑制纯色块/JPEG 抖动造成的误匹配。
        max_candidates:
            粗搜后进入全分辨率细化的候选数量，默认 6。
            增大可提高鲁棒性，但耗时增加。

    返回：
        MatchResult：包含 x、y、confidence、scale、matched_width、
        matched_height；未找到时返回 None。
        模板标准差 < 5 灰度级（过于平坦）时也返回 None。

    示例：
        >>> r = rustmatch.find("screenshot.png", "button.png")
        >>> if r:
        ...     print(f"位置=({r.x}, {r.y}) 倍率={r.scale:.3f} "
        ...           f"置信度={r.confidence:.2%}")

        >>> # 已知 DPI 范围时缩小搜索范围，速度更快
        >>> r = rustmatch.find("screenshot.png", "button.png",
        ...                    min_scale=0.5, max_scale=0.7)
    """
    return _find_template(
        source,
        template,
        threshold,
        **_scale_kwargs(scales, min_scale, max_scale, scale_step, min_std, max_candidates),
    )


def find_all(
    source: str,
    template: str,
    threshold: float = 0.8,
    max_count: int = 10,
    scales: _ScaleArgs = None,
    min_scale: Optional[float] = None,
    max_scale: Optional[float] = None,
    scale_step: float = 0.0,
    min_std: float = 2.0,
    max_candidates: int = 6,
) -> List[MatchResult]:
    """
    在源图中查找所有匹配位置（文件路径接口）。

    先通过自适应尺度搜索确定最佳倍率，再在该倍率下使用
    粗到细搜索 + 非极大值抑制（NMS）定位所有目标。

    参数：
        source:
            源图文件路径。
        template:
            模板图文件路径。
        threshold:
            匹配置信度门槛，默认 0.8。
        max_count:
            最多返回的匹配数量，默认 10。
        scales / min_scale / max_scale / scale_step / min_std / max_candidates:
            与 find() 含义相同。

    返回：
        MatchResult 列表，按置信度从高到低排序；未找到时返回空列表。

    示例：
        >>> results = rustmatch.find_all("screen.png", "star.png", max_count=5)
        >>> print(f"共找到 {len(results)} 个目标")
        >>> for r in results:
        ...     print(r.x, r.y, r.confidence, r.scale)
    """
    return _find_all_templates(
        source,
        template,
        threshold,
        max_count,
        **_scale_kwargs(scales, min_scale, max_scale, scale_step, min_std, max_candidates),
    )


def find_bytes(
    source: bytes,
    template: bytes,
    threshold: float = 0.8,
    scales: _ScaleArgs = None,
    min_scale: Optional[float] = None,
    max_scale: Optional[float] = None,
    scale_step: float = 0.0,
    min_std: float = 2.0,
    max_candidates: int = 6,
) -> Optional[MatchResult]:
    """
    在源图中查找单个最佳匹配（图像字节接口）。

    适用于内存中的截图数据（例如窗口截图、剪贴板、网络传输的图像），
    不需要先写入磁盘。缩放参数与 find() 完全一致。

    参数：
        source: 源图字节（PNG、JPEG 等编码后的数据）。
        template: 模板图字节。
        threshold: 最终置信度门槛，默认 0.8。
        scales / min_scale / max_scale / scale_step / min_std / max_candidates:
            与 find() 含义相同。

    返回：
        MatchResult 或 None。

    示例：
        >>> with open("screen.png", "rb") as f:
        ...     source = f.read()
        >>> with open("icon.png", "rb") as f:
        ...     template = f.read()
        >>> r = rustmatch.find_bytes(source, template)
    """
    return _find_template_bytes(
        source,
        template,
        threshold,
        **_scale_kwargs(scales, min_scale, max_scale, scale_step, min_std, max_candidates),
    )


def find_all_bytes(
    source: bytes,
    template: bytes,
    threshold: float = 0.8,
    max_count: int = 10,
    scales: _ScaleArgs = None,
    min_scale: Optional[float] = None,
    max_scale: Optional[float] = None,
    scale_step: float = 0.0,
    min_std: float = 2.0,
    max_candidates: int = 6,
) -> List[MatchResult]:
    """
    在源图中查找所有匹配位置（图像字节接口）。

    参数：
        source: 源图字节。
        template: 模板图字节。
        threshold: 置信度门槛，默认 0.8。
        max_count: 最多返回数量，默认 10。
        scales / min_scale / max_scale / scale_step / min_std / max_candidates:
            与 find() 含义相同。

    返回：
        MatchResult 列表，按置信度降序排列。
    """
    return _find_all_templates_bytes(
        source,
        template,
        threshold,
        max_count,
        **_scale_kwargs(scales, min_scale, max_scale, scale_step, min_std, max_candidates),
    )


def find_raw(
    source_pixels: Union[bytes, List[int]],
    source_width: int,
    source_height: int,
    template_pixels: Union[bytes, List[int]],
    template_width: int,
    template_height: int,
    threshold: float = 0.8,
    scales: _ScaleArgs = None,
    min_scale: Optional[float] = None,
    max_scale: Optional[float] = None,
    scale_step: float = 0.0,
    min_std: float = 2.0,
    max_candidates: int = 6,
) -> Optional[MatchResult]:
    """
    使用原始灰度像素查找单个匹配（高级接口）。

    适合已经自行完成图像解码/灰度转换的场景。
    像素按行优先（row-major）排列，每个像素取值范围 0–255。

    参数：
        source_pixels: 源图灰度像素，bytes 或 List[int]。
        source_width: 源图宽度。
        source_height: 源图高度。
        template_pixels: 模板灰度像素，bytes 或 List[int]。
        template_width: 模板宽度。
        template_height: 模板高度。
        threshold: 最终置信度门槛，默认 0.8。
        scales / min_scale / max_scale / scale_step / min_std / max_candidates:
            与 find() 含义相同。

    返回：
        MatchResult；未找到时返回 None。

    异常：
        像素数量与宽高不匹配时抛出 ValueError。
    """
    src = list(source_pixels) if isinstance(source_pixels, bytes) else source_pixels
    tpl = list(template_pixels) if isinstance(template_pixels, bytes) else template_pixels
    return _find_template_raw(
        src,
        source_width,
        source_height,
        tpl,
        template_width,
        template_height,
        threshold,
        **_scale_kwargs(scales, min_scale, max_scale, scale_step, min_std, max_candidates),
    )


def find_all_raw(
    source_pixels: Union[bytes, List[int]],
    source_width: int,
    source_height: int,
    template_pixels: Union[bytes, List[int]],
    template_width: int,
    template_height: int,
    threshold: float = 0.8,
    max_count: int = 10,
    scales: _ScaleArgs = None,
    min_scale: Optional[float] = None,
    max_scale: Optional[float] = None,
    scale_step: float = 0.0,
    min_std: float = 2.0,
    max_candidates: int = 6,
) -> List[MatchResult]:
    """
    使用原始灰度像素查找所有匹配位置（高级接口）。

    参数与 find_raw() 相同，额外支持 max_count 限制返回数量。

    返回：
        MatchResult 列表，按置信度降序排列。
    """
    src = list(source_pixels) if isinstance(source_pixels, bytes) else source_pixels
    tpl = list(template_pixels) if isinstance(template_pixels, bytes) else template_pixels
    return _find_all_templates_raw(
        src,
        source_width,
        source_height,
        tpl,
        template_width,
        template_height,
        threshold,
        max_count,
        **_scale_kwargs(scales, min_scale, max_scale, scale_step, min_std, max_candidates),
    )


def get_size(path: str) -> tuple:
    """
    读取图像文件的尺寸。

    参数：
        path: 图像文件路径。

    返回：
        (width, height) 元组，单位是像素。
    """
    return _get_image_size(path)


def get_size_bytes(data: bytes) -> tuple:
    """
    从图像字节数据读取尺寸。

    参数：
        data: 图像字节（PNG、JPEG 等编码数据）。

    返回：
        (width, height) 元组，单位是像素。
    """
    return _get_image_size_bytes(data)


def set_threads(num: int = 0) -> None:
    """
    设置匹配使用的线程数。

    注意：线程池只能初始化一次，应在第一次匹配调用之前设置。

    参数：
        num: 线程数；0 表示自动根据 CPU 核心数决定。
    """
    set_num_threads(num)


def version() -> str:
    """返回 RustMatch 的版本号字符串，例如 "0.1.0"。"""
    return _version()
